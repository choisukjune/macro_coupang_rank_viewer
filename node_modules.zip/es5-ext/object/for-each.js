"use strict";

module.exports = require("./_iterate")("forEach");
